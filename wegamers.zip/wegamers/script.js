let tournaments = [
    { id: 1, name: "Free Fire Daily", prize: "?500", entry: "Free", img: "https://via.placeholder.com/200x120?text=Free+Fire" },
    { id: 2, name: "BGMI Mega Cup", prize: "?2000", entry: "?20", img: "https://via.placeholder.com/200x120?text=BGMI" },
    { id: 3, name: "CODM Pro League", prize: "?1500", entry: "?15", img: "https://via.placeholder.com/200x120?text=CODM" }
];

let leaderboardData = [
    { user: "Raj", points: 120 },
    { user: "Aman", points: 110 },
    { user: "Simran", points: 90 }
];

function showLogin() {
    toggleScreen("login-screen");
}

function showSignup() {
    toggleScreen("signup-screen");
}

function showTournaments() {
    toggleScreen("tournament-screen");
    renderTournaments();
}

function showLeaderboard() {
    toggleScreen("leaderboard-screen");
    renderLeaderboard();
}

function toggleScreen(screenId) {
    document.querySelectorAll(".screen").forEach(s => s.classList.add("hidden"));
    document.getElementById(screenId).classList.remove("hidden");
}

function login() {
    let user = document.getElementById("username").value;
    let pass = document.getElementById("password").value;

    if (user && pass) {
        localStorage.setItem("loggedUser", user);
        document.getElementById("profile-name").textContent = user;
        showTournaments();
    } else {
        alert("Enter username and password!");
    }
}

function signup() {
    let user = document.getElementById("signup-username").value;
    let pass = document.getElementById("signup-password").value;

    if (user && pass) {
        alert("Signup successful! Please login.");
        showLogin();
    } else {
        alert("Fill all fields!");
    }
}

function renderTournaments() {
    let list = document.getElementById("tournament-list");
    list.innerHTML = "";
    tournaments.forEach(t => {
        let div = document.createElement("div");
        div.classList.add("tournament-card");
        div.innerHTML = `
            <img src="${t.img}" alt="${t.name}">
            <h3>${t.name}</h3>
            <p>Prize: ${t.prize}</p>
            <p>Entry: ${t.entry}</p>
            <button onclick="joinTournament('${t.name}')">Join</button>
        `;
        list.appendChild(div);
    });
}

function renderLeaderboard() {
    let lb = document.getElementById("leaderboard");
    lb.innerHTML = "";
    leaderboardData
        .sort((a, b) => b.points - a.points)
        .forEach(p => {
            let li = document.createElement("li");
            li.textContent = `${p.user} - ${p.points} pts`;
            lb.appendChild(li);
        });
}

function joinTournament(name) {
    alert(`? You joined ${name} tournament!`);
}

function logout() {
    localStorage.removeItem("loggedUser");
    showLogin();
}

// Auto login if user is already stored
window.onload = () => {
    let user = localStorage.getItem("loggedUser");
    if (user) {
        document.getElementById("profile-name").textContent = user;
        showTournaments();
    }
};
